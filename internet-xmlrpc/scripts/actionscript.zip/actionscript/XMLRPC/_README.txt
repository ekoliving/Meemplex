#################################################
#                                               #
#       XMLRPC for ActionScript 2.0             #
#        http://xmlrpcflash.sf.net              #
#                                               #
#################################################

NOTE: The AddParameter method arguments have changed in v 0.84!


Nothing here yet but, if you have any questions or 
suggestions please email me:

Matt Shaw <matt@dopelogik.com>